import java.util.PriorityQueue;
import java.util.ArrayList;

public class Assign10 {

    public PriorityQueue<Edge> edgeSet = new PriorityQueue<>();
  	public ArrayList<Edge> edgeMST = new ArrayList<>();
  	public int[] parentStr;
    
    public static void main(String[] args) {
      int graph[][] = new int[][] {   { 0, 2, 4, 1, 0, 0, 0 },
                                      { 2, 0, 0, 3,10, 0, 0 },
                                      { 4, 0, 0, 2, 0, 5, 0 },
                                      { 1, 3, 2, 0, 7, 8, 4 },
                                      { 0,10, 0, 7, 0, 0, 6 },
                                      { 0, 0, 5, 8, 0, 0, 1 },
                                      { 0, 0, 0, 4, 6, 1, 0 } };
      
      Assign10 mainMethod = new Assign10();

      System.out.println("Reading graph...");		

      for(int i=0;i<graph.length;i++)
      {
        for(int j=0;j<graph[i].length;j++)
        {
          if(i<=j && graph[i][j]!=0)
          {
            System.out.println("Added edge from " + (char)(i+65) + " to " + (char)(j+65) + " with dist " + graph[i][j]);
            Edge current = new Edge(i,j,graph[i][j]);
            mainMethod.edgeSet.add(current);
          }
        }
      }
      System.out.println("Added " + mainMethod.edgeSet.size() + " edges.");

      System.out.println("Computing MST...");
      mainMethod.kruskalMST(graph.length);
      
      int i=0;
      for(Edge e: mainMethod.edgeMST)
      {
     	i++;
        System.out.println("Edge " + i + ": from " + (char)(e.nodeA+65) + " to " + (char)(e.nodeB+65) + " with dist " + e.dist);
      }
    }
  
  	private void kruskalMST(int graphSize)
    {
      int edgeCount = 0;
      
      parentStr = new int[graphSize];
      for(int i=0;i<parentStr.length;i++)
        parentStr[i]=i;
      
      while(edgeCount < graphSize - 1 && edgeSet.size() > 0)
      {
        Edge current = edgeSet.poll();
        
        if(!isCycle(current.nodeA, current.nodeB))
        {
         	edgeMST.add(current); 
          	graphJoining(current.nodeA, current.nodeB);
        }
      }
    }
  
  	private boolean isCycle(int nodeA, int nodeB)
    {
      int parentA, parentB;

      parentA = findParent(nodeA);
      parentB = findParent(nodeB);

      if(parentA == parentB)
        return true;
      else
        return false;
    }
  	
  	private void graphJoining(int nodeA, int nodeB)
    {
      int parentA, parentB;

      parentA = findParent(nodeA);
      parentB = findParent(nodeB);
      
      parentStr[parentA] = parentB;	
    }
  	
  	private int findParent(int node)
    {
      int current = node;
      
      while(parentStr[current] != current)
        current = parentStr[current];
      
      return current;
    }
  
  	/*private void printSet()
    {
      	System.out.println("");
        while(edgeSet.size()!=0)
        {
          Edge current = edgeSet.poll();
          System.out.println(current.nodeA + " " + current.nodeB + " " + current.dist);
        }
    }*/
    
}

