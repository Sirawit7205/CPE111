import java.util.PriorityQueue;
import java.util.ArrayList;

public class Edge implements Comparable<Edge>{
    int nodeA, nodeB, dist;
    
    public Edge() {}
    
    public Edge(int nodea, int nodeb, int distance)
    {
        nodeA = nodea;
        nodeB = nodeb;
        dist = distance;
    }
    
    @Override
    public int compareTo(Edge o)
    {
        if(this.dist != o.dist)
          return (int) this.dist - o.dist;
      	else if(this.nodeA != o.nodeA)
          return (int) this.nodeA - o.nodeA;
        else
          return (int) this.nodeB - o.nodeB;
    }
}